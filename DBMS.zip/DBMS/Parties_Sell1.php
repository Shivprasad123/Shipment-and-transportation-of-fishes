<html>
	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">   

		<title>Extract_Details</title>
		<style>
       			table, th, td,tr{
                        	border: 1px solid black;
                        	text-align:center;
			}
                     #hom    {
                               margin-left:1235px;
			  }
			
	         label {
                                height:30px;
                                width:100px;

                        }

		</style>

	</head>
	<body>
		<?php
			echo "<h2><b><u>Welcome:".$_GET['id']."</u></b></h2>";
		?>
                <form id ="hom" class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
		</form>
	    <h4><u>Amount of Fishes Acc. Parties</u></h4>
                <form method='POST' action=''>
                <input class = 'btn-default' type='submit' value='Submit' name = 'sub2'/><br>
                </form>
		<?php
			//echo "<h2><b>Welcome:".$_GET['id']."</b></h2>";
                        if(isset($_POST['sub2'])){
                        $con = mysqli_connect("localhost:3306","root","9900478089","Project");
                        $qry = "select * from Fish_Details";
                        $result = mysqli_query($con,$qry);
                        $row2 = mysqli_fetch_fields($result);
                        $col = count($row2);
                        $i =0;
                        echo "<table><tr>";
                        echo "<th colspan=6>No. of Fishes</th></tr><tr>";
                        foreach($row2 as $val){
                                echo "<th style = color:brown>".$val->name."</th>";
                        }
                        echo "</tr>";
                        while($row = mysqli_fetch_array($result)){
                        echo "<tr>";
                        while($i < $col){
                                echo "<td>".$row[$i]."</td>";
                                $i = $i + 1;
                        }
                        $i = 0;
                        echo "</tr>";
                        mysqli_close($con);
                        }
                        }
        ?>

		<form  method = 'POST' action=''>
			<h4><u>Select Fish Name to get Fish_Cost Parties wise:</u> </h4>
			<select  name='fname' class='btn-default'>
				<option value='Prawns'>PRAWNS</option>
				<option value='Mackerel'>MACKEREL</option>
				<option value='Sardine'>SARDINE</option>
				<option value='Pomfret'>POMFRET</option>
			</select>
			<!--<input type='text' name = 'fname'/>-->
			<input class = 'btn-default' type='submit' value='Submit' name = 'sub'/><br>
		</form>
		<?php
			if(isset($_POST['sub'])){
			$con = mysqli_connect("localhost:3306","root","9900478089","Project");
			$qry = "select P_Id , F_Cost from Fish_Cost where F_Type = '".$_POST['fname']."' order by F_Cost ";
			$result = mysqli_query($con,$qry);
			$row2 = mysqli_fetch_fields($result);
			$col = count($row2);
			$i =0;
			echo "<table><tr>";
			echo "<th colspan=4>Contents of Fish_Cost_Details Table</th></tr><tr>";
			foreach($row2 as $val){
				echo "<th style = color:brown>".$val->name."</th>";
			}
			echo "</tr>";
			while($row = mysqli_fetch_array($result)){
			echo "<tr>";
			while($i < $col){
				echo "<td>".$row[$i]."</td>";
				$i = $i + 1;
			}
			$i = 0;
			echo "</tr>";
			mysqli_close($con);
			}
			}
?>
		<form  method = 'POST' action=''>
			<h4></b><u>Select Fish Name to Order: </u></b></h4>
			<label>P_Id:</label>
			<input type='text' name='pid' placeholder='Enter P_Id to sell' /><br>
			<label>No_of_Sacks:</label>
			<input type='text' name='sacks' placeholder='Amount of fishes (sacks)' /><br>
			<select  name='fnam' class='btn-default'>
				<option value='Prawns'>PRAWNS</option>
				<option value='Mackerel'>MACKEREL</option>
				<option value='Sardine'>SARDINE</option>
				<option value='Pomfret'>POMFRET</option>
			</select>
			<br><br>
			<input class = 'btn-default' type='submit' name='sub1' value='Order'/>
				<input class='btn-default' type='submit' value='Order_Recived' name='or'>
		</form>
<?php
			$id  = $_GET['id'];
			if(isset($_POST['sub1'])){
				$con = mysqli_connect("localhost:3306","root","9900478089","Project");
				$qry1 = "call Fish_Remove('".$_POST['fnam']."',".$_POST['sacks'].",'".$_POST['pid']."')";
				if($result = mysqli_query($con,$qry1)){
					echo "<h2>Ordered Successfully</h2>";
					echo "<h3><b>Transportaion Details are...</b></h3>";
			//	}else{
			//		echo "<h3 style = 'color:red'><b>".mysqli_error($con)."</b></h3>";
			//	}
				$qry2 = "select * from Chk_Driver";
				$result1 = mysqli_query($con,$qry2);
				$chk=1;
				while($row= mysqli_fetch_array($result1)){
					$val = strcmp($row['Availability'],'y');
					if($val==0){
						$chk=0;
						$did=$row['D_Id'];
						$qry3 = "update Chk_Driver set Availability = 'n' where D_Id='".$row['D_Id']."'";
						$update = mysqli_query($con,$qry3);
						$qry4 = "select * from Driver_Details d,Vehicle_Details v where v.D_Id=d.D_Id and v.D_Id='".$row['D_Id']."'";
						$qry7 = "insert into Ord_Details values ('".$id."','".$row['D_Id']."')";
						if($res7 = mysqli_query($con,$qry7)){
						}
						else{
							echo "ERROR".mysqli_error($con);
						}
						$result5 = mysqli_query($con,$qry4);
						$row3 = mysqli_fetch_fields($result5);
						$col = count($row3);
						$i = 0;
						$j=0;
						echo "<table><tr>";
						echo "<th colspan=9>Driver_Details</th></tr><tr>";
						foreach($row3 as $val){
							echo "<th style = color:brown>".$val->name."</th>";
						}
						echo "</tr>";
						while($row4 = mysqli_fetch_array($result5)){
							echo "<tr>";
							while($i<$col){
								echo "<td>".$row4[$i]."</td>";
								$i = $i + 1;
							}
							$i = 0;
							echo "</tr>";
						}
						break;
						}else{
							echo "ERROR".mysqli_error($con);
						}
					}
			//	}
				if($chk!=0){
					echo "<b>Vehicles are not available at this moment<b>";
				}
		
			}else{
				echo "<h3 style = 'color:red'><b>".mysqli_error($con)."</b></h3>";
			}
			}
	
			mysqli_close($con);
			if(isset($_POST['or'])){
				$con = mysqli_connect("localhost:3306","root","9900478089","Project");
				$qry9 = "update Chk_Driver set Availability='y' where D_Id in (select D_Id from Ord_Details where C_Id= '".$id."')";
				$qry10 = "delete from Ord_Details where C_Id='".$id."'";
				if($result6 = mysqli_query($con,$qry9)){
					echo "<h3><b>Thank_You</b><h3><br>";
					$result9 = mysqli_query($con,$qry10);
					//echo $qry10;
				}else{
					echo "<h3 style = 'color:red'><b>".mysqli_error($con)."</b></h3>";
				}
			}
	?>
	</body>
</html>
