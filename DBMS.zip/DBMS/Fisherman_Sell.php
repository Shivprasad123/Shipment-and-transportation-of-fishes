<html>
	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">   

		<title>Extract_Details</title>
		<style>
       			table, th, td,tr{
                        	border: 1px solid black;
                        	text-align:center;
			}
                     #hom    {
                               margin-left:1235px;
			  }

                 label {
                                height:30px;
                                width:100px;

                        }

		</style>

	</head>
	<body>
                <form id ="hom" class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
		</form>
		<form  method = 'POST' action=''>
			<h4><b><u>Select Fish Name to get Fish_Cost Parties wise:</u></b> </h4>
			<select  name='fname' class ='btn-default'>
				<option value='Prawns'>PRAWNS</option>
				<option value='Mackerel'>MACKEREL</option>
				<option value='Sardine'>SARDINE</option>
				<option value='Pomfret'>POMFRET</option>
			</select>
			<!--<input type='text' name = 'fname'/>-->
			<input class = 'btn-default' type='submit' value='Submit' name = 'sub'/><br>
		</form>
			<?php
			if(isset($_POST['sub'])){
			$con = mysqli_connect("localhost:3306","root","9900478089","Project");
			$qry = "select P_Id , F_Cost from Fish_Cost where F_Type = '".$_POST['fname']."' order by F_Cost desc";
			$result = mysqli_query($con,$qry);
			$row2 = mysqli_fetch_fields($result);
			$col = count($row2);
			$i =0;
			echo "<table style =float:center;><tr>";
			echo "<th colspan=4>Contents of Fish_Cost_Details Table</th></tr><tr>";
			foreach($row2 as $val){
				echo "<th style = color:brown>".$val->name."</th>";
			}
			echo "</tr>";
			while($row = mysqli_fetch_array($result)){
			echo "<tr>";
			while($i < $col){
				echo "<td>".$row[$i]."</td>";
				$i = $i + 1;
			}
			$i = 0;
			echo "</tr>";
			mysqli_close($con);
			}
			}
?>
		<form  method = 'POST' action=''>
			<br>
			<h4><b><u>Select Fish Name to Sell:</u></b></h4>
			<label>P_Id:</label>
			<input type='text' name='pid' placeholder='Enter P_Id to sell' required/><br>
			<label>No_of_Sacks:</label>
			<input type='text' name='sacks' placeholder='Amount of fishes (sacks)'required/><br>
			<select  name='fnam' class='btn-default'>
				<option value='Prawns'>PRAWNS</option>
				<option value='Mackerel'>MACKEREL</option>
				<option value='Sardine'>SARDINE</option>
				<option value='Pomfret'>POMFRET</option>
			</select>
			<input class = 'btn-default' type='submit' name='sub1' value='Sell'/>
		</form>
		<?php
			if(isset($_POST['sub1'])){
				$con = mysqli_connect("localhost:3306","root","9900478089","Project");
				$qry1 = "call Fish_Add('".$_POST['fnam']."',".$_POST['sacks'].",'".$_POST['pid']."')";
				if($result = mysqli_query($con,$qry1)){
					echo "<center><h3>Sold</h3></center>";
				}else{
					echo "Error".mysqli_error($con);
				}
			}	
	?>
	</body>
</html>
