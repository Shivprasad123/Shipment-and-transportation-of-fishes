<!DOCTYPE html>
<html>
	<head>
		<title>Fisherman_Insert</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

		<style>
			table, th, td ,tr{
			border:1px solid black;
			text-align:center;
			}
			label {
				height:30px;
				width :60px;
			}
			#hom {
				margin-left:1220px;

			}
		</style>

	</head>
	<body style="background: url(img6.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;">

		<h1 style="background-color:brown"><marquee>
			The Fisherman_Details:
			</marquee>
			
		</h1>	
			   <form id ="hom" class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
                        </form>



	                  <form class="form-group" action="/DBMS/Fisherman_DetailsIn.php">
                                <input class="btn-default" type="submit" value="Insert"/><br><br>
                        </form>


			<form method="POST" action=''>
				<label>Search : </label>
				<input id = "demo" type = "text" name = "fman" placeholder="Enter to search" size ="10" align= "left" required/><br>
				<label>By     : </label>
				<input id = "demo1" type = "text" name = "by" placeholder="Enter Field to search" size ="10" align= "left" required/><br>
				<input  style = "position :relative ; left : 63px"class = "btn-default" type ="submit" name = "sub" value="submit"><br>
			</form>
				<?php
						$link = mysqli_connect("localhost:3306","root","9900478089","Project");
						$qry = "Select * from Fisherman_Details";
						$result = mysqli_query($link,$qry);
						//$row1 = mysqli_fetch_array($result);
						$row2 = mysqli_fetch_fields($result);
						$col = count($row2);
						$i = 0;
						$j=0;
						if(isset($_POST['sub'])){
							$ckey=$_POST['fman'];
							$by1 = $_POST['by'];
							$sign = explode(" ",$ckey);
							$qry1 = "select * from Fisherman_Details where ".$by1."".$sign[0]."'".$sign[1]."'";
							$res = mysqli_query($link,$qry1);

							echo "<table style = 'float:left;'><tr>";
						foreach($row2 as $val){
							echo "<th style = color:brown>".$val->name."</th>";
						}
						echo "</tr>";
						while($row5 = mysqli_fetch_array($res)){
							echo "<tr>";
							while($j<$col){
								echo "<td>".$row5[$j]."</td>";
								$j = $j + 1;
							}
							$j = 0;
							echo "</tr>";
						}
						echo "</table>";
						}
						echo "<center>";
						echo "<table style =float:center;color:green><tr>";
						echo "<th colspan=5>Contents of Fisherman_Details Table</th></tr><tr>";
						foreach($row2 as $val){
							echo "<th style = color:brown>".$val->name."</th>";
						}
						echo "</tr>";
						while($row = mysqli_fetch_array($result)){
							echo "<tr>";
							while($i<$col){
								echo "<td>".$row[$i]."</td>";
								$i = $i + 1;
							}
							$i = 0;
							echo "</tr>";
						}
				?>
	
	</body>
</html>
