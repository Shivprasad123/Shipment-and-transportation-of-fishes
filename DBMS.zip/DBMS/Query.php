<!DOCTYPE html>
<html>
	<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> 
		<style>
			table, th, td {
			border:1px solid black;
			text-align:center;
			}
			h1{
				color:red;
			}
		</style>

	</head>
	<body>
		<center>
			<form method="POST">
				<input id="demo" type="text" name="query" placeholder = "Enter Query here" required/>
				<button class="btn-default" type="submit">Submit</button>
			</form>
			<h2>
				<?php
					if(isset($_POST['query'])){
						$qry1=$_POST['query'];
					}
					$submit = $_POST;
					if($submit){
					$link = mysqli_connect("localhost:3306","root","9900478089","Project");
					$qry = $qry1;
				
					echo "<h1>Details For '".$qry."' is :</h1>";
						$result = mysqli_query($link,$qry);
						
					//	$row1 = mysqli_fetch_array($result);
						$row2 = mysqli_fetch_fields($result);
						$col = count($row2);
			//			echo $columns;
						$i = 0;
						echo "<table><tr>";
			//			echo $row2;
						foreach($row2 as $val){
							echo "<th>".$val->name."</th>";
						//	$i = $i +1;
						}
						echo "</tr>";
						while(($row = mysqli_fetch_array($result))){
							echo "<tr>";
						//	$col = count($row)/2;
							while($i<$col){
								echo "<td>".$row[$i]."</td>";
								$i = $i + 1;
							}
							$i = 0;
							echo "</tr>";
						}
						echo "</table>";
					}
				?>
			</h2>
	</center>
	</body>
</html>
