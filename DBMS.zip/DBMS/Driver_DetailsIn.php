<!DOCTYPE>
<html>
	<head>
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<title>Driver_Insert</title>

	<style>
		label {
                color:blue;
                text-align:center;
                height:30px;
                width:100px;
                }
		#log{
			margin-left:1230px;
		}
	</style>
	</head>
	<body style="background: url(img15.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;" >

                <form class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
		</form>
		<center>

			<form class = "form-group" method="POST">
			<label style= background-color:white ><b>D_Id:</b></label>
			<input id ="demo" type = "text" name = "D_id" placeholder = "Enter Driver ID" required/><br>
			<label style = "background-color:white"><b>D_Name:</b></label>
			<input id = "demo1" type = "text" name = "Dname" placeholder = "Enter Driver name" required/><br>
			<label style = "background-color:white"><b>D_Address:</b></label>
			<input id = "demo2" type = "text" name = "DAdd" placeholder = "Enter Driver Address" required/><br>
			<label style = "background-color:white"><b>D_Phone:</b></label>
			<input id = "demo3" type = "text" name = "Dphone" placeholder = "Enter Driver phone number" required/><br>
			<input style = "position : absolute ; left : 610px" class = "btn-default" type="submit" value="Insert"/>
                	</form>
               		<form class="form-group" action="/DBMS/Driver_Details.php">
                        <input style = "position : absolute ; left : 690px ; top : 205px" class="btn-default" type="submit" value="check_Table"/>
			</form>
			<h1 style=color:green>
				<?php
					$name="";
					//$pass="";
					$count = 1;
					$count1 = 0;
					$submit = $_POST;
					if(isset($_POST['D_id'])){
						$c_id = $_POST['D_id'];
					}
					if(isset($_POST['Dname'])){
						$cname = $_POST['Dname'];
					}
					if(isset($_POST['DAdd'])){
						$cloc = $_POST['DAdd'];
					}
					if(isset($_POST['Dphone'])){
						$cphone = $_POST['Dphone'];
					}
					if($submit){
						$link = mysqli_connect("localhost:3306","root","9900478089","Project");
						if($result = mysqli_query($link,"insert into Driver_Details values('".$c_id."','".$cname."','".$cloc."',".$cphone.')')){
							echo "VAlue inserted.....";
						}
						else{
                                                	echo "Error".mysqli_error($link);
						}

					}
					mysqli_close($link);
				?>
			</h1>
		</center>
               

	</body>
</html>
