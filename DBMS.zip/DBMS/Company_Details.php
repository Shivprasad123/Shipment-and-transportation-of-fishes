<!DOCTYPE html>
<html>
	<head>
		<title>Company_Details</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">	

		<style>
			table, th, td,tr{
			border: 1px solid black;
			text-align:center;
			}
			label {
				height:30px;
				width:60px;
			
			}
			#hom	{
                        	margin-left:1220px;
                	}

		</style>

	</head>
	<body style="background: url(10.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;">

		<h1><marquee>
			 Company Details:
			</marquee>
			
		</h1>	
			<form id ="hom" class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
                        </form>
			

	                <form class="form-group" action="/DBMS/Company_DetailsIn.php">
        	                <input class="btn-default" type="submit" value="Insert "/><br><br>
                	</form>
			


			<form method="POST" action=''>

				<label>Search:     </label>
				<input id = "demo" type = "text" name = "company" placeholder="Enter C_ID to search" size ="10" align= "left" required/><br>
				<label>By:     </label>
				<input  id = "demo1" type = "text" name = "by" placeholder="Enter Field to search" size ="10" align= "left" required/><br>
				<input style = "position:relative ; left :70px" class = "btn-default" type ="Submit" name = "Sub" value="Submit"><br><br>
			</form>
				<?php
						$link = mysqli_connect("localhost:3306","root","9900478089","Project");
						$qry = "Select * from Company_Details";
						$result = mysqli_query($link,$qry);
						//$row1 = mysqli_fetch_array($result);
						$row2 = mysqli_fetch_fields($result);
						$col = count($row2);
						$i = 0;
						$j=0;
						$submit =  $_POST;
						if($submit){
							$ckey=$_POST['company'];
							$by1 = $_POST['by'];
							$sign = explode(" ",$ckey);
							$qry1 = "select * from Company_Details where ".$by1."".$sign[0]."'".$sign[1]."'";
							$res = mysqli_query($link,$qry1);
							//echo $qry1;

							echo "<table style = 'float:left; background-color:white'><tr>";
						foreach($row2 as $val){
							echo "<th style = color:brown>".$val->name."</th>";
						}
						echo "</tr>";
						while($row5 = mysqli_fetch_array($res)){
							echo "<tr>";
							while($j<$col){
								echo "<td>".$row5[$j]."</td>";
								$j = $j + 1;
							}
							$j = 0;
							echo "</tr>";
						}
						echo "</table>";
						}
						echo "<center>";
						echo "<table style = 'float:center; background-color:white;'><tr>";
						echo "<th colspan=4>Contents of Company_Details Table</th></tr><tr>";
						foreach($row2 as $val){
							echo "<th style = color:brown>".$val->name."</th>";
						}
						echo "</tr>";
						while($row = mysqli_fetch_array($result)){
							echo "<tr>";
							while($i<$col){
								echo "<td>".$row[$i]."</td>";
								$i = $i + 1;
							}
							$i = 0;
							echo "</tr>";
						}
				?>
	
	</body>
</html>
