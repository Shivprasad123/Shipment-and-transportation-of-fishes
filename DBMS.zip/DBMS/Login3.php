<!DOCTYPE>
<html>
	<head>
	<style>
		table, th, td {
		border:1px solid black;
		text-align:center;
		}
	</style>
	</head>
	<body style="background: url(img1.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;">
		<center>
			<form method="POST">
			<label><b>Username:</b></label>
			<input id ="demo" type = "text" name = "uname"  required/><br>
			<label><b>Password:</b></label>
			<input id = "demo1" type = "password" name = "passwd" required/><br>
			<label><b>re-Password:</b></label>
			<input id = "demo1" type = "password" name = "rpasswd" required/><br>
			<label><b>Name:</b></label>
			<input id ="demo2" type = "text" name = "name"  required/><br>
			<label><b>Email:</b></label>
			<input id ="demo3" type = "text" name = "email"  required/><br>
			<button type="submit">"Submit"</button>
			</form>
			<h1>
				<?php
					$name="";
					$pass="";
					if(isset($_POST['uname'])){
						$name = $_POST['uname'];
					}
					if(isset($_POST['passwd'])){
						$pass = $_POST['passwd'];
					}
					if(isset($_POST['name'])){
						$nam = $_POST['name'];
					}
					if(isset($_POST['email'])){
						$email = $_POST['email'];
					}
					if(isset($_POST['rpasswd'])){
						$rpass = $_POST['rpasswd'];
					}
					if($pass==$rpass){
					$link = mysqli_connect("localhost:3306","root","9900478089","Login");
					if(mysqli_query($link,"insert into User_Details values('".$name."','".$pass."')") && mysqli_query($link,"insert into About_User values('".$name."','".$pass."','".$nam."','".$email."')")){
						echo "User Account created";
					}
					else{
						echo "Error".mysqli_error($link);
					}
					$result = mysqli_query($link,"select * from User_Details");
					echo "<table><tr><th>Name</th><th>Password</th></tr>";
					while($row = mysqli_fetch_array($result)){
						echo "<tr>";
						echo "<td>".$row['Uname']."</td>";
						echo "<td>".$row['Passwd']."</td>";
						echo "</tr>";
					}
					}
					else{
						echo "Password Don't match";
					}
					$name="";
					$pass="";

					mysqli_close($link);
				?>
			</h1>
		</center>
	</body>
</html>
