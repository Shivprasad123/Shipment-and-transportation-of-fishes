<!DOCTYPE>
<html>
	<head>
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script>
		function printing(){
		var v = document.getElementById("demo").value;
		document.getElementById("demo1").innerHTML = v;
		}
	</script>
	<head>
	<body>
		<center>
		<form method="POST">
		<input id = "demo" type="text" name = "mytext" value="demo"/>
<button type="submit">"Make POST Requst"</button>
		</form>
		<button class = "btn" onclick ='printing()'>Submit</button>
		<h1 id = "demo1"></h1>
		<h2>
			<?php
				if(isset($_POST['mytext'])){
					$mytext = $_POST['mytext'];
					echo $mytext;
				}
				else{
					echo "NOthing"	;
				}
			?>
		</h2>
		</center>
	</body>
</html>
