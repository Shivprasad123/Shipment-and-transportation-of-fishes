<!DOCTYPE>
<html>
	<head>
 		 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<title> Register </title>
	<style>
		
		label {
			height:30px;
			color:#950;
			text-align:center;
			width:100px;
			text-decoration: underline;
			background-color:white;
		}
		#det{
			font-family:serif;
			text-decoration: underline;
		}
		#but{
			position:absolute;
			left:660px;
		}
		#log{
			position:absolute;
			left:550px;
			top:310px;
		}
		#acc{
			position:absolute;
			left:550px;
			top:350px;
		}
	</style>
	</head>
	<body style="background:url(9.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;">
		<center>
			<div id='det'>
			<h1 style = 'color:cyan;text-decoration: underline;'><b>Enter The following details to Register<b></h1>
			<form class = "form-group" method="POST">
			<label><b>Name        :<b></label>
			<input id ="demo2" type = "text" name = "name"  placeholder = "Enter your name" required/><br>
			<label><b>Username        :<b> </label>
			<input id ="demo" type = "text" name = "uname" placeholder = "Enter username" required/><br>
			<label><b>Password       :</b></label>
			<input id = "demo1" type = "password" name = "passwd" placeholder = "Enter password" required/><br>
			<label><b>Re-Passwd   : </b></label>
			<input id = "demo1" type = "password" name = "rpasswd" placeholder = "re-enter password" required/><br>
			<label><b>Email:    </b></label>
			<input id ="demo3" type = "text" name = "email" placeholder = "Enter your email_id" required/><br>
		<div id='but'>	<button class = "btn-default" type="submit">Submit</button><br><br></div>
			</form>
			<div id='log'>
			<form action = "/DBMS/Login1.php">
				<input style ="position:relative; left:45px"class = "btn-default" type = "submit" value = "Go Back to Login_Page"\>	
			</form>
			</div>
			</div>
			<h1>
				<?php
					//$name="";
					//$pass="";

					$submit = $_POST;
					if(isset($_POST['uname'])){
						$name = $_POST['uname'];
					}
					if(isset($_POST['passwd'])){
						$pass = $_POST['passwd'];
					}
					if(isset($_POST['name'])){
						$nam = $_POST['name'];
					}
					if(isset($_POST['email'])){
						$email = $_POST['email'];
					}
					if(isset($_POST['rpasswd'])){
						$rpass = $_POST['rpasswd'];
					}
					
					if($submit){
					if($pass==$rpass){
					$link = mysqli_connect("localhost:3306","root","9900478089","Login");
					if(mysqli_query($link,"insert into About_User values('".$name."','".$pass."','".$nam."','".$email."')")){
						echo "<div id='acc'>User Account created</div>";
					}
					else{
						echo "<div id='acc'>Error".mysqli_error($link)."</div>";
					}
					}else{
						echo " <div id='acc'>Please enter correct password</div>";
					}
					$name="";
					$pass="";

					mysqli_close($link);
					}
				?>
			</h1>
		</center>
	</body>
</html>
