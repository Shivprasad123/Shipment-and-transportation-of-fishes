<!DOCTYPE>
<html>
	<head>
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

		<title>Welcome to S.T.A.R</title>

	</head>
	<style>
		#log {
			margin-left:1100px;
		}
		#wel{
			font-family:serif;
		}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 200px;
    background-color: #f1f1f1;
    border: 1px solid #555;
}

li a {
    display: block;
    color: #000;
    text-decoration: none;
    padding: 8px 16px;

}

li {
    text-align: center;
    border-bottom: 1px solid #555;
}

li:last-child {
    border-bottom: none;
}

li a.active {
    background-color: #4CAF50;
    color: white;
}

li a:hover:not(.active) {
    background-color: #4CAF50;
    color: white;
}
	</style>

	<body style="background: url(2.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;">
	<div id='wel'>
		<h1><b style='color:cyan; text-decoration: underline;'><marquee>WELCOME</marquee></b></h1>
	</div>
	<div id='log'>
		<ul>
			<li><a href='/DBMS/Login1.php'>LogOut</a></li>
		</ul>
	</div>
<ul>
  <li><a href="/DBMS/Query.php">Try Query</a></li>
  <li><a href="/DBMS/Company_Details.php">Company_Details</a></li>
  <li><a href="/DBMS/Driver_Details.php">Driver_Details</a></li>
  <li><a href="/DBMS/Parties.php">Parties_Details</a></li>
  <li><a href="/DBMS/Fisherman_Details.php">Fisherman_Details</a></li>
  <li><a href="/DBMS/Fish_Details.php">Fish_Details</a></li>
  <li><a href="/DBMS/Fish_Cost.php">Fish_Cost</a></li>
  <li><a href="/DBMS/Vehicle_Details.php">Vehicle_Details</a></li>
  <li><a href="/DBMS/Transportation_Details.php">Transportation_Details</a></li>
  <li><a href="/DBMS/Queries1.php">Quries</a></li>
</ul>
	</body>
</html>
