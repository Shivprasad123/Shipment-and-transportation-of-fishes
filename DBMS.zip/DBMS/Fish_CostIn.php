<!DOCTYPE>
<html>
	<head>
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<title>Fish_Cost_Insert</title>

	<style>
	    label {
                color:blue;
                text-align:center;
                height:30px;
                width:100px;
                }

	       #log{
                        margin-left:1230px;
                }

		
	</style>
	</head>
	<body style="background: url(img15.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;" >
		<form class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
                </form>

		<center>
			<form class = "form-group" method="POST">
			<label style= background-color:white ><b>P_Id :</b></label>
			<input id ="demo" type = "text" name = "c_id" placeholder="Enter P_Id" required/><br>
			<label style = "background-color:white"><b>F_Type:</b></label>
			<input id = "demo1" type = "text" name = "cname" placeholder = "Enter Fish Type" required/><br>
			<label style = "background-color:white"><b>F_Cost:</b></label>
			<input id = "demo3" type = "text" name = "cphone" placeholder = "Enter Fish Cost" required/><br>
			<input class = "btn-default" style ="position : absolute ; left : 608px"  type="submit" value="Insert"/>
                	</form>
		<form class="form-group" action="/DBMS/Fish_Cost.php">
			<input class="btn-default" style ="position : absolute ; left : 690px ; top : 166px"  type="submit" value="check_Table"/>
                </form>
			<h1 style=color:green>
				<?php
					$name="";
					//$pass="";
					$count = 1;
					$count1 = 0;
					$submit = $_POST;
					if(isset($_POST['c_id'])){
						$c_id = $_POST['c_id'];
					}
					if(isset($_POST['cname'])){
						$cname = $_POST['cname'];
					}
					if(isset($_POST['cphone'])){
						$cphone = $_POST['cphone'];
					}
					if($submit){
						$link = mysqli_connect("localhost:3306","root","9900478089","Project");
						if($result = mysqli_query($link,"insert into Fish_Cost values('".$c_id."','".$cname."',".$cphone.')')){
							echo "VAlue inserted.....";
						}
						else{
                                                	echo "Error".mysqli_error($link);
						}

					}
					mysqli_close($link);
				?>
			</h1>
		</center>
	</body>
</html>
