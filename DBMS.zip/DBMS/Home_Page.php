<!DOCTYPE>
<html>
	<head>
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<title>Welcome to S.T.A.R</title>

	</head>
	<style>
		#log {
			margin-left:1100px;
		}
		#wel{
			font-family:serif;
		}
ul {
	position:absolute;
	top:100px;
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 200px;
    background-color: #f1f1f1;
    border: 1px solid #555;
}

li a {
    display: block;
    color: #000;
    text-decoration: none;
    padding: 8px 16px;

}

li {
    text-align: center;
    border-bottom: 1px solid #555;
}

li:last-child {
    border-bottom: none;
}

li a.active {
    background-color: #4CAF50;
    color: white;
}

li a:hover:not(.active) {
    background-color: #4CAF50;
    color: white;
}


#log ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

#log li {
    border-right:1px solid #bbb;
}
#log li:last-child {
    border-right: none;
}

#log li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

#log li a:hover:not(.active) {
    background-color: #111;
}

#log .active {
    background-color: #4CAF50;
}
	</style>

	<body style="background: url(12.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;">
	<div id='wel'>
		<?php 
			$name = $_GET['id'];
			echo "<h1><span style='color:cyan;background-color:black'><b><u>WELCOME:</u></b>".$name."<span></h1>";
		?>
	</div>
	<div id='log'>
		<ul>
			<li><a href='/DBMS/About.php'>About</a></li>
			<li><a href='/DBMS/Contact.php'>Contact us</a></li>
			<li><a href='/DBMS/Login1.php'>LogOut</a></li>
		</ul>
	</div>
<ul>
  <li><a href="/DBMS/Query.php">Try Query</a></li>
  <li><a href="/DBMS/Company_Details.php">Company_Details</a></li>
  <li><a href="/DBMS/Driver_Details.php">Driver_Details</a></li>
  <li><a href="/DBMS/Parties.php">Parties_Details</a></li>
  <li><a href="/DBMS/Fisherman_Details.php">Fisherman_Details</a></li>
  <li><a href="/DBMS/Fish_Details.php">Fish_Details</a></li>
  <li><a href="/DBMS/Fish_Cost.php">Fish_Cost</a></li>
  <li><a href="/DBMS/Vehicle_Details.php">Vehicle_Details</a></li>
  <li><a href="/DBMS/Transportation_Details.php">Transportation_Details</a></li>
  <li><a href="/DBMS/Queries.php">Queries</a></li>
  <li><a href="/DBMS/Process.php">Process</a></li>
</ul>
	<div class="w3-content w3-section" style="width:800px ; max-height:500px ;position:absolute ; top:87px ;left:253px">

  <img class="mySlides w3-animate-fading" src="23.jpg" style="width:100%;height:430px">
  <img class="mySlides w3-animate-fading" src="30.jpg" style="width:100%;height:430px">
  <img class="mySlides w3-animate-fading" src="31.jpg" style="width:100%;height:430px">
  <img class="mySlides w3-animate-fading" src="32.jpg" style="width:100%;height:430px">
  <img class="mySlides w3-animate-fading" src="33.jpg" style="width:100%;height:430px">
  <img class="mySlides w3-animate-fading" src="34.jpg" style="width:100%;height:430px">
  <img class="mySlides w3-animate-fading" src="35.jpg" style="width:100%;height:430px">
  <img class="mySlides w3-animate-fading" src="351.jpg" style="width:100%;height:430px">
</div>

			<script>
			var myIndex = 0;
			carousel();

			function carousel() {
				    var i;
				        var x = document.getElementsByClassName("mySlides");
				        for (i = 0; i < x.length; i++) {
						       x[i].style.display = "none";  
						           }
					    myIndex++;
					    if (myIndex > x.length) {myIndex = 1}    
						        x[myIndex-1].style.display = "block";  
					        setTimeout(carousel, 8000);    
			}
			</script>

	
	</body>
</html>
