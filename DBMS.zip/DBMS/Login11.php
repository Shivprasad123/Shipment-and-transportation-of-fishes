<!DOCTYPE>
<html>
	<head>
		 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<title>Log_In</title>

	<style>
		table, th, td {
		border:1px solid black;
		text-align:center;
		}
		#login{
			position:absolute;
			border:2px solid black;
			top:150px;
			left:949px;
			width:350px;
			height:250px;
			background : url(lck.jpg) no-repeat;
			background-size:100%;
		}
		#quote{
			position:absolute;
			border:2px solid black;
			top:450px;
			left:950px;
			width:350px;
			height:100px;
		}
		#head{
			position:absolute;
			color:white;
		}
		body{
			background-color:#328;
		}
		#about{
			position:absolute;
			top:150px;	
			width:900px;
			text-align:left;
		}
		#star{
			position:absolute;
			left:500px;
			top:50px;
			text-decoration: underline;
			text-shadow: 3px 3px black;
			font-family:serif;
		}
		#fman{
			text-shadow: 3px 2px red;
			font-family:serif;
			text-decoration:underline;
		}
		#poorf {
			font-family:serif;
			color:black;
		}
		#sign{
			position:absolute;
			left:220px;
			top:134px;
		}
		#log{
			position:absolute;
			left:120px;
		}
	</style>
	</head>
	
		<body><div id = 'head'  style="background: url(9.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;" >
			<div id='star'>
			<h1 style = "position:relative ; left :500px; font-size:60px "><b>S.T.A.R</b></h1>
			</div>
		</div>
		<div id='about'>
			<div id='fman'>
			<h2><b style='color:cyan'>FisherMan:</b><br></h2>
			</div>

			<div id = "poorf">	
			<h2 >	“A poor fisherman who knows the beauties of the misty mornings is much richer than a wealthy man who sleeps till noon in his palace....!”  </h2>
		</div>
		</div>
		<div id='quote'>
			<p>BHJBFJ lkfeifhoiu kfnieuh erejjnfehg eruthoiuerht weuithoieurho wer hieuhoei wuhgeriuoh oiueh</p>
		</div>
		<div id = 'login'>

			<center>
			<h3 style = 'color:white; text-decoration: underline;'><b>Login/Sign Up</b></h3>
			<form class = "form-group" method="POST" action=''>
			<label style='color:white  ;text-decoration: underline;'><b>Username:</b></label>
			<input id ="demo" color = 'black' type = "text" class = 'btn-default' name = "uname" placeholder="Enter username" required/><br>
			<label style= 'color:white; text-decoration: underline;'><b>Password:</b></label>
			<input id = "demo1" color = 'black' type = "password" class = 'btn-default' name = "passwd" placeholder = "Enter password" required/><br><br>
			<div id='log'>
			<button class = "btn" type="submit">Log_In</button>
			</div>
			</form>
			<div id='sign'>
			<form class = "form-group" action="/DBMS/Login2.php">
				<input class = "btn" type="submit" value="Sign_Up"/>
			</form>
			</div>
			</center>
	<!--		<script>
				alert('User Logged in Successfully.');
			</script>-->
			<h1 style=color:green>
				<?php
					$name="";
					$count = 1;
					$count1 = 0;
					$submit = $_POST;
					if(isset($_POST['uname'])){
						$name = $_POST['uname'];
					}
					if(isset($_POST['passwd'])){
						$pass = $_POST['passwd'];
					}
					if($submit){
					$link = mysqli_connect("localhost:3306/Login","root","9900478089","Login");
					$result = mysqli_query($link,"select * from About_User");

					$row1 = mysqli_fetch_array($result);
					$chk = 0;
					while($row= mysqli_fetch_array($result)){
						if($name == $row['Uname'] && $pass== $row['Passwd']){
							$chk =1;
							echo " User Logged in Correctly";
							header("Location:/DBMS/Home_Page.php?id=".$row['Name']);
							break;
						}
					}
					if($chk==0){
						echo "Username and Password Don't match";
					}
					if($row1 == ""){
							echo "...Username and Password Don't Match...";
					}
					mysqli_close($link);
					}
				?>
			</h1>
		</div>
		</div>
	</body>
</html>
