<!DOCTYPE>
<html>
	<head>
		 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<title>Process</title>

	<style>
		table, th, td {
		border:1px solid black;
		text-align:center;
		}

	       #hom    {
	                 margin-left:1240px;
	      }
	 
		#login{
			position:absolute;
			border:2px solid black;
			top:150px;
			left:949px;
			width:350px;
			height:250px;
			background : url(lck.jpg) no-repeat;
			background-size:100%;
		}
		#login1{
			position:absolute;
			border:2px solid black;
			top:150px;
			left:100px;
			width:350px;
			height:250px;
			background : url(lck.jpg) no-repeat;
			background-size:100%;
		}
		#head{
			position:absolute;
			color:black;
		}
		#star{
			position:absolute;
			left:80px;
			color:cyan;
			top:30px;
			text-decoration: underline;
			text-shadow: 3px 3px black;
			font-family:serif;
			padding:10px;
		}
	</style>
	</head>
		<body id = 'head'  style="background: url(12.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;" >
			<div id='star'>
			<h1 style = "position:relative ; left :500px; font-size:60px "><b>S.T.A.R</b></h1>
			</div>
                    <form id ="hom" class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
                        </form>
		<div id = 'login'>

			<center>
			<h3 style = 'color:white; text-decoration: underline;'><b>Fman : Login/Sign Up</b></h3>
			<form class = "form-group" method="POST" action=''>
			<label style='color:white  ;text-decoration: underline;'><b>Username:</b></label>
			<input color = 'black' id ="demo" type = "text" name = "uname" placeholder="Enter username" required/><br>
			<label style= 'color:white; text-decoration: underline;'><b>Password:</b></label>
			<input id = "demo1" type = "password" name = "passwd" placeholder = "Enter password" required/><br><br>
			<div id='log'>
			<button class = "btn-primary" type="submit" name='sub'>Log_In</button>
			</div>
			</form>
			</div>
			</center>
			<h1 style=color:green>
				<?php
					$name="";
					$count = 1;
					$count1 = 0;
					if(isset($_POST['uname'])){
						$name = $_POST['uname'];
					}
					if(isset($_POST['passwd'])){
						$pass = $_POST['passwd'];
					}
					if(isset($_POST['sub'])){
					$link = mysqli_connect("localhost:3306/Login","root","9900478089","Login");
					$result = mysqli_query($link,"select * from About_Fisherman");

					$row1 = mysqli_fetch_array($result);
					$chk = 0;
					while($row= mysqli_fetch_array($result)){
						if($name == $row['Uname'] && $pass== $row['Passwd']){
							$chk =1;
							header("Location:/DBMS/Fisherman_Sell.php");
							break;
						}
					}
					if($chk==0){
						echo "Username and Password Don't match";
					}
					if($row1 == ""){
							echo "...Username and Password Don't Match...";
					}
					mysqli_close($link);
					}
				?>
			</h1>
		</div>
		</div>
		<div id = 'login1'>

			<center>
			<h3 style = 'color:white; text-decoration: underline;'><b>Company : Login/Sign Up</b></h3>
			<form class = "form-group" method="POST" action=''>
			<label style='color:white  ;text-decoration: underline;'><b>Username:</b></label>
			<input id ="demo" type = "text" name = "uname" placeholder="Enter username" required/><br>
			<label style= 'color:white; text-decoration: underline;'><b>Password:</b></label>
			<input id = "demo1" type = "password" name = "passwd" placeholder = "Enter password" required/><br><br>
			<div id='log'>
			<button class = "btn-primary" type="submit" name='sub1'>Log_In</button>
			</div>
			</form>
			</div>
			</center>
			<h1 style=color:green>
				<?php
					$name="";
					$count = 1;
					$count1 = 0;
					if(isset($_POST['uname'])){
						$name = $_POST['uname'];
					}
					if(isset($_POST['passwd'])){
						$pass = $_POST['passwd'];
					}
					if(isset($_POST['sub1'])){
					$link = mysqli_connect("localhost:3306/Login","root","9900478089","Login");
					$result = mysqli_query($link,"select * from About_Parties");

					$row1 = mysqli_fetch_array($result);
					$chk = 0;
					while($row= mysqli_fetch_array($result)){
						if($name == $row['Uname'] && $pass== $row['Passwd']){
							$chk =1;
							header("Location:/DBMS/Parties_Sell.php?id=".$name."");
							break;
						}
					}
					if($chk==0){
						echo "Username and Password Don't match";
					}
					if($row1 == ""){
							echo "...Username and Password Don't Match...";
					}
					mysqli_close($link);
					}
				?>
			</h1>
		</div>
		</div>
	</body>
</html>
