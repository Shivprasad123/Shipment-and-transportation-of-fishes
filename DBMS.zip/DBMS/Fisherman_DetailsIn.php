<!DOCTYPE>
<html>
	<head>
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<title>Company_Details</title>

	<style>
		 label {
                color:blue;
                text-align:center;
                height:30px;
                width:100px;
                }
                #log{
                        margin-left:1230px;
                }
		
	</style>
	</head>
	<body style="background: url(img15.jpg) no-repeat; width: 100%; height: 150px; background-size: 100%;" >
		
		<form class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
                </form>
		<center>
			<form class = "form-group" method="POST">
			<label style= background-color:white ><b>F_Id:</b></label>
			<input id ="demo" type = "text" name = "c_id" placeholder="Enter F_Id" required/><br>
			<label style = "background-color:white"><b>F_Name:</b></label>
			<input id = "demo1" type = "text" name = "cname" placeholder = "Enter Fisherman name" required/><br>
			<label style= background-color:white ><b>p_Id:</b></label>
			<input id ="demo" type = "text" name = "p_id" placeholder="Enter P_Id" required/><br>
			<label style = "background-color:white"><b>F_Phone:</b></label>
			<input id = "demo3" type = "text" name = "cphone" placeholder = "Enter Fisherman Phone number" required/><br>
			<label style = "background-color:white"><b>F_Address:</b></label>
			<input id = "demo2" type = "text" name = "cloc" placeholder = "Enter Fisherman Address" required/><br>
			<input style ="position : absolute ; left : 610" class = "btn-default" type="submit" value="Insert"/>
                	</form>
			<form class="form-group" action="/DBMS/Fisherman_Details.php">
			<input style ="position : absolute ; left : 690px ; top : 248px;" class="btn-default" type="submit" value="check_Table"/>
			</form>
			<h1 style=color:green>
				<?php
					$name="";
					//$pass="";
					$count = 1;
					$count1 = 0;
					$submit = $_POST;
					if(isset($_POST['c_id'])){
						$c_id = $_POST['c_id'];
					}
					if(isset($_POST['p_id'])){
						$p_id = $_POST['p_id'];
					}
					if(isset($_POST['cname'])){
						$cname = $_POST['cname'];
					}
					if(isset($_POST['cloc'])){
						$cloc = $_POST['cloc'];
					}
					if(isset($_POST['cphone'])){
						$cphone = $_POST['cphone'];
					}
					if($submit){
						$link = mysqli_connect("localhost:3306","root","9900478089","Project");
						if($result = mysqli_query($link,"insert into Fisherman_Details values('".$c_id."','".$cname."','".$p_id."',".$cphone.",'".$cloc."')")){
							echo "VAlue inserted.....";
						}
						else{
                                                	echo "Error".mysqli_error($link);
						}

					}
					mysqli_close($link);
				?>
			</h1>
		</center>

	</body>
</html>
