<html>
	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">   

		<title>Extract_Details</title>
		<style>
       			table, th, td,tr{
                        	border: 1px solid black;
                        	text-align:center;
			}
                     #hom    {
                               margin-left:1235px;
			  }
			       
		</style>

	</head>
	<body>
                <form id ="hom" class="form-group" action="/DBMS/Home_Page.php">
                        <input class="btn-default" type="submit" value="Home"/>
                </form>
		<form  method = 'POST' action=''>
			<h4><b><u>1.Enter Fish Name to get Fish_Cost Parties wise:</u></b> </h4>
			<select  name='fname' class='btn-default'>
				<option value='Prawns'>PRAWNS</option>
				<option value='Mackerel'>MACKEREL</option>
				<option value='Sardine'>SARDINE</option>
				<option value='Pomfret'>POMFRET</option>
			</select>
			<!--<input type='text' name = 'fname'/>-->
			<input class = 'btn-default' type='submit' value='Submit' name = 'sub'/>
		</form>

		<?php
			if(isset($_POST['sub'])){
			$con = mysqli_connect("localhost:3306","root","9900478089","Project");
			$qry = "select * from Fish_Cost where F_Type = '".$_POST['fname']."' order by F_Cost";
			$result = mysqli_query($con,$qry);
			$row2 = mysqli_fetch_fields($result);
			$col = count($row2);
			$i =0;
			echo "<table><tr>";
			echo "<th colspan=4>Contents of Fish_Cost_Details Table</th></tr><tr>";
			foreach($row2 as $val){
				echo "<th style = color:brown>".$val->name."</th>";
			}
			echo "</tr>";
			while($row = mysqli_fetch_array($result)){
			echo "<tr>";
			while($i < $col){
				echo "<td>".$row[$i]."</td>";
				$i = $i + 1;
			}
			$i = 0;
			echo "</tr>";
			mysqli_close($con);
			}
			}	
	?>
		<form method='POST' action=''>
			<h4><b><u>2.Transportation b/w Dates:</u></b></h4>
			<input name = 'date_in' type='date'/>
			<input name = 'date_out' type = 'date'/>
			<input class = 'btn-default' type='submit' value='Submit' name = 'sub1'/>
		</form>
		<?php
			if(isset($_POST['sub1'])){
			$con = mysqli_connect("localhost:3306","root","9900478089","Project");
			$qry = "select P_Id,Date_Id,Date_Out,Destination from Transportation_Details where Date_Id between '".$_POST['date_in']."' and '".$_POST['date_out']."' order by Date_Id";
			$result = mysqli_query($con,$qry);
			$row2 = mysqli_fetch_fields($result);
			$col = count($row2);
			$i =0;
			echo "<table><tr>";
			echo "<th colspan=4>Contents of Fish_Cost_Details Table</th></tr><tr>";
			foreach($row2 as $val){
				echo "<th style = color:brown>".$val->name."</th>";
			}
			echo "</tr>";
			while($row = mysqli_fetch_array($result)){
			echo "<tr>";
			while($i < $col){
				echo "<td>".$row[$i]."</td>";
				$i = $i + 1;
			}
			$i = 0;
			echo "</tr>";
			mysqli_close($con);
			}
			}	
	?>
	<h4><b><u>3.Amount of Fishes Acc. Parties:</u></b></h4>
		<form method='POST' action=''>
		<input class = 'btn-default' type='submit' value='Submit' name = 'sub2'/>
		</form>
		<?php
			if(isset($_POST['sub2'])){
			$con = mysqli_connect("localhost:3306","root","9900478089","Project");
			$qry = "select * from Fish_Details";
			$result = mysqli_query($con,$qry);
			$row2 = mysqli_fetch_fields($result);
			$col = count($row2);
			$i =0;
			echo "<table style =float:center;><tr>";
			echo "<th colspan=6>Contents of Fish_Cost_Details Table</th></tr><tr>";
			foreach($row2 as $val){
				echo "<th style = color:brown>".$val->name."</th>";
			}
			echo "</tr>";
			while($row = mysqli_fetch_array($result)){
			echo "<tr>";
			while($i < $col){
				echo "<td>".$row[$i]."</td>";
				$i = $i + 1;
			}
			$i = 0;
			echo "</tr>";
			mysqli_close($con);
			}
			}	
	?>
	</body>
</html>
